package com.stickermaker.app

import android.content.Context
import android.graphics.*
import android.os.Build
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import kotlin.math.min

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun Context.toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

class Sticker(val file: String, val emoji: String)
class Pack(val id: String, var name: String, var animated: Boolean,
           val stickers: MutableList<Sticker> = mutableListOf(), var version: Int = 1)

/** Guarda los packs en filesDir/packs/<id>/ y el índice en packs.json */
class PackStore private constructor(ctx: Context) {
    private val root = File(ctx.filesDir, "packs").apply { mkdirs() }
    private val index = File(ctx.filesDir, "packs.json")
    private val packs = mutableListOf<Pack>()
    init { load() }

    companion object {
        const val MIN = 3
        const val MAX = 30
        @Volatile private var inst: PackStore? = null
        fun get(ctx: Context): PackStore = inst ?: synchronized(this) {
            inst ?: PackStore(ctx.applicationContext).also { inst = it }
        }
    }

    @Synchronized fun all(): List<Pack> = packs.toList()
    @Synchronized fun find(id: String): Pack? = packs.firstOrNull { it.id == id }
    fun dir(id: String) = File(root, id).apply { mkdirs() }
    fun stickerFile(id: String, f: String) = File(dir(id), f)
    fun thumbFile(id: String, f: String) = File(dir(id), f.substringBefore('.') + ".png")
    fun trayFile(id: String) = File(dir(id), "tray.png")

    @Synchronized fun create(name: String): Pack {
        val p = Pack(UUID.randomUUID().toString().take(12), name, false)
        packs.add(p); save(); return p
    }

    @Synchronized fun delete(id: String) {
        packs.removeAll { it.id == id }; File(root, id).deleteRecursively(); save()
    }

    @Synchronized fun addSticker(id: String, webp: ByteArray, animated: Boolean, art: Bitmap, emoji: String) {
        val p = find(id) ?: return
        val n = (p.stickers.maxOfOrNull { it.file.substringBefore('.').toIntOrNull() ?: 0 } ?: 0) + 1
        stickerFile(id, "$n.webp").writeBytes(webp)
        png(art, 160, File(dir(id), "$n.png"))
        if (p.stickers.isEmpty()) { p.animated = animated; png(art, 96, trayFile(id)) }
        p.stickers.add(Sticker("$n.webp", emoji)); p.version++; save()
    }

    @Synchronized fun removeSticker(id: String, f: String) {
        val p = find(id) ?: return
        if (p.stickers.removeAll { it.file == f }) {
            stickerFile(id, f).delete(); thumbFile(id, f).delete(); p.version++; save()
        }
    }

    private fun png(b: Bitmap, size: Int, f: File) {
        val s = Bitmap.createScaledBitmap(b, size, size, true)
        f.outputStream().use { s.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private fun save() {
        val arr = JSONArray()
        packs.forEach { p ->
            val st = JSONArray()
            p.stickers.forEach { st.put(JSONObject().put("file", it.file).put("emoji", it.emoji)) }
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("animated", p.animated)
                .put("version", p.version).put("stickers", st))
        }
        index.writeText(arr.toString())
    }

    private fun load() {
        if (!index.exists()) return
        runCatching {
            val arr = JSONArray(index.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); val st = o.getJSONArray("stickers")
                val l = mutableListOf<Sticker>()
                for (j in 0 until st.length()) st.getJSONObject(j).let { l.add(Sticker(it.getString("file"), it.getString("emoji"))) }
                packs.add(Pack(o.getString("id"), o.getString("name"), o.getBoolean("animated"), l, o.getInt("version")))
            }
        }
    }
}

object StickerRenderer {
    const val SIZE = 512

    fun initialMatrix(w: Int, h: Int): Matrix {
        val s = min(SIZE.toFloat() / w, SIZE.toFloat() / h)
        return Matrix().apply { setScale(s, s); postTranslate((SIZE - w * s) / 2f, (SIZE - h * s) / 2f) }
    }

    fun drawCaption(c: Canvas, text: String) {
        if (text.isBlank()) return
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER; textSize = 72f
        }
        while (fill.measureText(text) > SIZE - 40 && fill.textSize > 20f) fill.textSize -= 2f
        val stroke = Paint(fill).apply { style = Paint.Style.STROKE; strokeWidth = fill.textSize / 6f; color = Color.BLACK }
        c.drawText(text, SIZE / 2f, SIZE - 36f, stroke); c.drawText(text, SIZE / 2f, SIZE - 36f, fill)
    }

    /** Dibuja un fotograma en el lienzo 512x512 usando el encuadre (stage) que eligió el usuario. */
    fun render(frame: Bitmap, stage: Matrix, refW: Int, refH: Int, caption: String): Bitmap {
        val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val m = Matrix().apply { setScale(refW.toFloat() / frame.width, refH.toFloat() / frame.height); postConcat(stage) }
        c.drawBitmap(frame, m, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        drawCaption(c, caption)
        return out
    }
}

/** Genera WebP estático (<100 KB) y WebP animado (<500 KB) sin librerías externas. */
object WebpEncoder {
    private const val MAX_STATIC = 100 * 1024
    private const val MAX_ANIM = 500 * 1024

    @Suppress("DEPRECATION")
    private fun compress(b: Bitmap, q: Int): ByteArray {
        val o = ByteArrayOutputStream()
        b.compress(if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP, q, o)
        return o.toByteArray()
    }

    fun encodeStatic(b: Bitmap): ByteArray {
        var q = 95; var d = compress(b, q)
        while (d.size > MAX_STATIC && q > 10) { q -= 10; d = compress(b, q) }
        return d
    }

    fun encodeAnimated(frames: List<Bitmap>, frameMs: Int): ByteArray {
        var list = frames; var ms = frameMs
        while (true) {
            for (q in intArrayOf(75, 60, 45, 30, 20)) {
                val d = mux(list.map { compress(it, q) }, ms)
                if (d.size <= MAX_ANIM) return d
            }
            if (list.size <= 6) throw IllegalStateException("El sticker animado pesa demasiado. Prueba con un clip más corto.")
            list = list.filterIndexed { i, _ -> i % 2 == 0 }; ms *= 2
        }
    }

    private fun le(v: Int, n: Int) = ByteArray(n) { ((v shr (8 * it)) and 0xFF).toByte() }
    private fun chunk(o: ByteArrayOutputStream, tag: String, p: ByteArray) {
        o.write(tag.toByteArray(Charsets.US_ASCII)); o.write(le(p.size, 4)); o.write(p)
        if (p.size % 2 == 1) o.write(0)
    }

    /** Extrae los chunks ALPH/VP8/VP8L de un WebP de un solo cuadro. */
    private fun frameData(w: ByteArray): ByteArray {
        val o = ByteArrayOutputStream(); var p = 12
        while (p + 8 <= w.size) {
            val tag = String(w, p, 4, Charsets.US_ASCII)
            val size = (0..3).sumOf { (w[p + 4 + it].toInt() and 0xFF) shl (8 * it) }
            val padded = size + (size and 1)
            if (tag == "ALPH" || tag == "VP8 " || tag == "VP8L") o.write(w, p, min(w.size, p + 8 + padded) - p)
            p += 8 + padded
        }
        return o.toByteArray()
    }

    private fun mux(frames: List<ByteArray>, ms: Int): ByteArray {
        val s = StickerRenderer.SIZE - 1
        val body = ByteArrayOutputStream()
        body.write("WEBP".toByteArray(Charsets.US_ASCII))
        chunk(body, "VP8X", byteArrayOf(0x12, 0, 0, 0) + le(s, 3) + le(s, 3))
        chunk(body, "ANIM", ByteArray(6))
        for (f in frames) chunk(body, "ANMF", le(0, 3) + le(0, 3) + le(s, 3) + le(s, 3) + le(ms, 3) + byteArrayOf(0x02) + frameData(f))
        val out = ByteArrayOutputStream()
        out.write("RIFF".toByteArray(Charsets.US_ASCII)); out.write(le(body.size(), 4)); out.write(body.toByteArray())
        return out.toByteArray()
    }
}
