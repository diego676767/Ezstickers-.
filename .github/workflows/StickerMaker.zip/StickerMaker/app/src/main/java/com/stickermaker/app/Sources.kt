package com.stickermaker.app

import android.content.Context
import android.graphics.*
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.Closeable
import kotlin.math.max
import kotlin.math.min

interface FrameSource : Closeable {
    val animated: Boolean
    val durationMs: Long
    fun frameAt(tMs: Long): Bitmap
}

object Sources {
    fun open(ctx: Context, uri: Uri): FrameSource {
        val t = ctx.contentResolver.getType(uri) ?: ""
        return when {
            t.startsWith("video/") -> VideoSource(ctx, uri)
            t == "image/gif" -> GifSource(ctx, uri).let { if (it.animated) it else ImageSource(ctx, uri) }
            else -> ImageSource(ctx, uri)
        }
    }
}

class ImageSource(ctx: Context, uri: Uri) : FrameSource {
    override val animated = false
    override val durationMs = 0L
    private val bmp: Bitmap = decode(ctx, uri)
    override fun frameAt(tMs: Long) = bmp
    override fun close() {}

    private fun decode(ctx: Context, uri: Uri): Bitmap {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
        var b = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IllegalStateException("No se pudo abrir la imagen")
        val o = runCatching {
            cr.openInputStream(uri)!!.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }
        }.getOrDefault(1)
        val m = Matrix()
        when (o) { 6 -> m.postRotate(90f); 3 -> m.postRotate(180f); 8 -> m.postRotate(270f); 2 -> m.postScale(-1f, 1f) }
        if (!m.isIdentity) b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
        return b
    }
}

class GifSource(ctx: Context, uri: Uri) : FrameSource {
    @Suppress("DEPRECATION")
    private val movie: Movie = ctx.contentResolver.openInputStream(uri)!!.use { Movie.decodeStream(it) }
        ?: throw IllegalStateException("GIF no válido")
    override val durationMs = movie.duration().toLong()
    override val animated get() = durationMs > 0
    private val k = min(1f, 640f / max(movie.width(), movie.height()))
    private val w = max(1, (movie.width() * k).toInt())
    private val h = max(1, (movie.height() * k).toInt())
    override fun frameAt(tMs: Long): Bitmap {
        movie.setTime(if (durationMs > 0) (tMs % durationMs).toInt() else 0)
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b); c.scale(k, k); movie.draw(c, 0f, 0f)
        return b
    }
    override fun close() {}
}

class VideoSource(ctx: Context, uri: Uri) : FrameSource {
    private val r = MediaMetadataRetriever().apply { setDataSource(ctx, uri) }
    override val animated = true
    override val durationMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    private val dw: Int
    private val dh: Int
    init {
        fun md(k: Int, d: Int) = r.extractMetadata(k)?.toIntOrNull() ?: d
        var w = md(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH, 480)
        var h = md(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT, 480)
        val rot = md(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION, 0)
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        val s = min(1f, 720f / max(w, h))
        dw = max(1, (w * s).toInt()); dh = max(1, (h * s).toInt())
    }
    override fun frameAt(tMs: Long): Bitmap =
        r.getScaledFrameAtTime(min(tMs, max(0, durationMs - 1)) * 1000, MediaMetadataRetriever.OPTION_CLOSEST, dw, dh)
            ?: throw IllegalStateException("No se pudo leer el video")
    override fun close() = r.release()
}
