package com.stickermaker.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/** Lienzo cuadrado: arrastra para mover, pellizca para zoom. `stage` está en coordenadas 512x512. */
class CropView(ctx: Context) : View(ctx) {
    var bitmap: Bitmap? = null
    val stage = Matrix()
    var caption = ""
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val bg = Paint().apply { color = 0xFFE6E6E6.toInt() }
    private var lx = 0f
    private var ly = 0f
    private fun k() = StickerRenderer.SIZE / width.toFloat()

    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            stage.postScale(d.scaleFactor, d.scaleFactor, d.focusX * k(), d.focusY * k()); invalidate(); return true
        }
    })

    override fun onMeasure(w: Int, h: Int) { val s = MeasureSpec.getSize(w); setMeasuredDimension(s, s) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
            MotionEvent.ACTION_POINTER_UP -> { val i = if (e.actionIndex == 0) 1 else 0; lx = e.getX(i); ly = e.getY(i) }
            MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1 && !scaler.isInProgress) {
                stage.postTranslate((e.x - lx) * k(), (e.y - ly) * k()); lx = e.x; ly = e.y; invalidate()
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val s = StickerRenderer.SIZE.toFloat()
        c.scale(width / s, width / s)
        c.drawRect(0f, 0f, s, s, bg)
        bitmap?.let { c.drawBitmap(it, stage, paint) }
        StickerRenderer.drawCaption(c, caption)
    }
}
