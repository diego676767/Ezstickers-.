package com.stickermaker.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.min

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

class MainActivity : Activity() {
    private val store by lazy { PackStore.get(this) }
    private lateinit var list: ListView
    private lateinit var empty: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        title = "Mis packs de stickers"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)) }
        root.addView(Button(this).apply { text = "➕ Nuevo pack"; setOnClickListener { askName() } })
        empty = TextView(this).apply { text = "Crea tu primer pack para empezar."; gravity = Gravity.CENTER; setPadding(0, dp(40), 0, 0) }
        list = ListView(this)
        root.addView(empty); root.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        list.setOnItemClickListener { _, _, i, _ -> open(store.all()[i].id) }
        list.setOnItemLongClickListener { _, _, i, _ ->
            val p = store.all()[i]
            AlertDialog.Builder(this).setTitle("¿Eliminar \"${p.name}\"?")
                .setPositiveButton("Eliminar") { _, _ -> store.delete(p.id); refresh() }
                .setNegativeButton("Cancelar", null).show()
            true
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val packs = store.all()
        empty.visibility = if (packs.isEmpty()) View.VISIBLE else View.GONE
        val rows = packs.map {
            val tipo = if (it.stickers.isEmpty()) "" else if (it.animated) " · animado" else " · estático"
            "${it.name}\n${it.stickers.size}/${PackStore.MAX} stickers$tipo"
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
    }

    private fun open(id: String) = startActivity(Intent(this, PackActivity::class.java).putExtra("pack_id", id))

    private fun askName() {
        val input = EditText(this).apply { hint = "Nombre del pack"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Nuevo pack").setView(input)
            .setPositiveButton("Crear") { _, _ ->
                open(store.create(input.text.toString().trim().ifEmpty { "Mi pack" }.take(60)).id)
            }.setNegativeButton("Cancelar", null).show()
    }
}

class PackActivity : Activity() {
    private val store by lazy { PackStore.get(this) }
    private lateinit var packId: String
    private lateinit var grid: GridView
    private lateinit var info: TextView
    private lateinit var waBtn: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        packId = intent.getStringExtra("pack_id") ?: run { finish(); return }
        actionBar?.setDisplayHomeAsUpEnabled(true)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        info = TextView(this)
        grid = GridView(this).apply { numColumns = 3; horizontalSpacing = dp(6); verticalSpacing = dp(6) }
        waBtn = Button(this).apply { text = "Añadir a WhatsApp"; setOnClickListener { addToWhatsApp() } }
        root.addView(info)
        root.addView(Button(this).apply { text = "➕ Añadir sticker (foto, video o GIF)"; setOnClickListener { pick() } })
        root.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(waBtn)
        setContentView(root)
        grid.setOnItemLongClickListener { _, _, i, _ ->
            val s = store.find(packId)!!.stickers[i]
            AlertDialog.Builder(this).setTitle("¿Eliminar sticker?")
                .setPositiveButton("Eliminar") { _, _ -> store.removeSticker(packId, s.file); refresh() }
                .setNegativeButton("Cancelar", null).show()
            true
        }
    }

    override fun onOptionsItemSelected(i: MenuItem): Boolean { if (i.itemId == android.R.id.home) finish(); return true }
    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val p = store.find(packId) ?: return
        title = p.name
        val tipo = if (p.stickers.isEmpty()) "" else if (p.animated) " · pack animado" else " · pack estático"
        info.text = "${p.stickers.size}/${PackStore.MAX} stickers$tipo\nNecesitas mínimo ${PackStore.MIN} para añadirlo a WhatsApp. Mantén pulsado un sticker para borrarlo."
        waBtn.isEnabled = p.stickers.size >= PackStore.MIN
        grid.adapter = object : BaseAdapter() {
            override fun getCount() = p.stickers.size
            override fun getItem(i: Int) = p.stickers[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, parent: ViewGroup): View {
                val iv = (v as? ImageView) ?: ImageView(this@PackActivity).apply {
                    layoutParams = AbsListView.LayoutParams(MATCH, dp(110)); setBackgroundColor(0xFFEEEEEE.toInt())
                }
                iv.setImageBitmap(BitmapFactory.decodeFile(store.thumbFile(packId, p.stickers[i].file).path))
                return iv
            }
        }
    }

    private fun pick() {
        if ((store.find(packId)?.stickers?.size ?: 0) >= PackStore.MAX) { toast("El pack ya tiene ${PackStore.MAX} stickers"); return }
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*")), 1)
    }

    private fun installed(pkg: String) = try { packageManager.getPackageInfo(pkg, 0); true } catch (e: PackageManager.NameNotFoundException) { false }

    private fun addToWhatsApp() {
        val p = store.find(packId) ?: return
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { installed(it) } ?: run { toast("Instala WhatsApp primero"); return }
        val i = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK").setPackage(pkg)
            .putExtra("sticker_pack_id", p.id)
            .putExtra("sticker_pack_authority", StickerContentProvider.authority(this))
            .putExtra("sticker_pack_name", p.name)
        try { startActivityForResult(i, 2) } catch (e: ActivityNotFoundException) { toast("Actualiza WhatsApp: tu versión no admite packs de stickers") }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK && data?.data != null) {
            startActivity(Intent(this, EditorActivity::class.java).setData(data.data).putExtra("pack_id", packId)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }
        if (req == 2 && res == RESULT_CANCELED) data?.getStringExtra("validation_error")?.let { toast("WhatsApp rechazó el pack: $it") }
    }
}

class EditorActivity : Activity() {
    private val store by lazy { PackStore.get(this) }
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var packId: String
    private lateinit var crop: CropView
    private lateinit var caption: EditText
    private lateinit var progress: ProgressBar
    private lateinit var save: Button
    private var source: FrameSource? = null
    private var refW = 1
    private var refH = 1
    private val maxClipMs = 4000L
    private val fps = 10

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        title = "Editar sticker"
        packId = intent.getStringExtra("pack_id") ?: run { finish(); return }
        val uri = intent.data ?: run { finish(); return }
        actionBar?.setDisplayHomeAsUpEnabled(true)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        crop = CropView(this)
        caption = EditText(this).apply {
            hint = "Texto en el sticker (opcional)"; setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { crop.caption = s.toString(); crop.invalidate() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        progress = ProgressBar(this).apply { visibility = View.GONE }
        save = Button(this).apply { text = "Guardar en el pack"; isEnabled = false; setOnClickListener { save() } }
        root.addView(crop, LinearLayout.LayoutParams(MATCH, MATCH))
        root.addView(TextView(this).apply { text = "Pellizca para hacer zoom · arrastra para mover" ; gravity = Gravity.CENTER })
        root.addView(caption); root.addView(progress); root.addView(save)
        setContentView(ScrollView(this).apply { addView(root) })

        io.execute {
            try {
                val s = Sources.open(this, uri)
                val first = s.frameAt(0)
                runOnUiThread { loaded(s, first) }
            } catch (e: Exception) {
                runOnUiThread { toast("No se pudo abrir el archivo"); finish() }
            }
        }
    }

    override fun onOptionsItemSelected(i: MenuItem): Boolean { if (i.itemId == android.R.id.home) finish(); return true }
    override fun onDestroy() { super.onDestroy(); io.execute { source?.close() }; io.shutdown() }

    private fun loaded(s: FrameSource, first: Bitmap) {
        val p = store.find(packId)
        if (p != null && p.stickers.isNotEmpty() && p.animated != s.animated) {
            toast("Este pack es ${if (p.animated) "animado" else "estático"}; WhatsApp no permite mezclarlos. Crea otro pack."); finish(); return
        }
        source = s; refW = first.width; refH = first.height
        crop.bitmap = first; crop.stage.set(StickerRenderer.initialMatrix(refW, refH)); crop.invalidate()
        save.isEnabled = true
    }

    private fun save() {
        val s = source ?: return
        save.isEnabled = false; progress.visibility = View.VISIBLE
        val stage = Matrix(crop.stage); val cap = caption.text.toString().trim().take(40)
        io.execute {
            try {
                val art: Bitmap; val webp: ByteArray
                if (!s.animated) {
                    art = StickerRenderer.render(s.frameAt(0), stage, refW, refH, cap); webp = WebpEncoder.encodeStatic(art)
                } else {
                    val n = (min(maxClipMs, s.durationMs) * fps / 1000).toInt().coerceAtLeast(2)
                    val frames = (0 until n).map { StickerRenderer.render(s.frameAt(it * 1000L / fps), stage, refW, refH, cap) }
                    art = frames[0]; webp = WebpEncoder.encodeAnimated(frames, 1000 / fps)
                }
                store.addSticker(packId, webp, s.animated, art, "😀")
                runOnUiThread { finish() }
            } catch (e: Exception) {
                runOnUiThread { progress.visibility = View.GONE; save.isEnabled = true; toast(e.message ?: "Error al guardar") }
            }
        }
    }
}
