package com.stickermaker.app

import android.content.*
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor

/** Proveedor que WhatsApp consulta para leer los packs (formato oficial de WhatsApp Stickers). */
class StickerContentProvider : ContentProvider() {
    companion object {
        fun authority(c: Context) = c.packageName + ".stickercontentprovider"
        const val PUBLISHER = "Sticker Maker"
    }
    private lateinit var matcher: UriMatcher

    override fun onCreate(): Boolean {
        val a = authority(context!!)
        matcher = UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(a, "metadata", 1); addURI(a, "metadata/*", 2)
            addURI(a, "stickers/*", 3); addURI(a, "stickers_asset/*/*", 4)
        }
        return true
    }

    override fun query(uri: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor {
        val store = PackStore.get(context!!)
        val c = when (matcher.match(uri)) {
            1 -> packs(store.all().filter { it.stickers.size >= PackStore.MIN })
            2 -> packs(listOfNotNull(store.find(uri.lastPathSegment ?: "")))
            3 -> stickers(store.find(uri.lastPathSegment ?: ""))
            else -> throw IllegalArgumentException("URI desconocida: $uri")
        }
        c.setNotificationUri(context!!.contentResolver, uri)
        return c
    }

    private fun packs(l: List<Pack>) = MatrixCursor(arrayOf(
        "sticker_pack_identifier", "sticker_pack_name", "sticker_pack_publisher", "sticker_pack_icon",
        "android_play_store_link", "ios_app_download_link", "sticker_pack_publisher_email",
        "sticker_pack_publisher_website", "sticker_pack_privacy_policy_website",
        "sticker_pack_license_agreement_website", "image_data_version",
        "whatsapp_will_not_cache_stickers", "animated_sticker_pack")).apply {
        l.forEach { addRow(arrayOf(it.id, it.name, PUBLISHER, "tray.png", "", "", "", "", "", "",
            it.version.toString(), 0, if (it.animated) 1 else 0)) }
    }

    private fun stickers(p: Pack?) = MatrixCursor(arrayOf("sticker_file_name", "sticker_emoji", "sticker_accessibility_text")).apply {
        p?.stickers?.forEach { addRow(arrayOf(it.file, it.emoji, "Sticker")) }
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        if (matcher.match(uri) != 4) return null
        val seg = uri.pathSegments; val id = seg[seg.size - 2]; val name = seg.last()
        val store = PackStore.get(context!!); val pack = store.find(id) ?: return null
        val f = when {
            name == "tray.png" -> store.trayFile(id)
            pack.stickers.any { it.file == name } -> store.stickerFile(id, name)
            else -> return null
        }
        if (!f.exists()) return null
        return AssetFileDescriptor(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY), 0, AssetFileDescriptor.UNKNOWN_LENGTH)
    }

    override fun getType(uri: Uri): String? = when (matcher.match(uri)) {
        1 -> "vnd.android.cursor.dir/vnd.${authority(context!!)}.metadata"
        2 -> "vnd.android.cursor.item/vnd.${authority(context!!)}.metadata"
        3 -> "vnd.android.cursor.dir/vnd.${authority(context!!)}.stickers"
        4 -> if (uri.lastPathSegment == "tray.png") "image/png" else "image/webp"
        else -> null
    }
    override fun insert(uri: Uri, v: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<out String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<out String>?) = 0
}
