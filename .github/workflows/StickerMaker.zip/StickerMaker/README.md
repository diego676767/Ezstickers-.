# Sticker Maker (Android, Kotlin, sin dependencias externas)
1. Abre la carpeta en Android Studio (Hedgehog o más nuevo) y espera el Sync.
2. Run ▶ en tu móvil (necesita WhatsApp instalado) o Build > Build APK(s).
Flujo: Nuevo pack > Añadir sticker (foto/video/GIF) > zoom/mover/texto > Guardar > Añadir a WhatsApp (mín. 3 stickers).
Un pack es todo estático o todo animado (regla de WhatsApp). Animados: hasta 4 s, se comprimen solos a <500 KB.
Para Play Store cambia: applicationId, ícono, PUBLISHER (StickerContentProvider.kt) y targetSdk.
